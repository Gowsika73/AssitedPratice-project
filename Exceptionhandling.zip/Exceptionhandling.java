package AssistedPractice;

public class Exceptionhandling {

	public static void main(String[] args) {
		try {
            int a = 33, b = 0;
            int c = a/b;  // cannot divide by 0
            System.out.println ("Result:" + c);
        }
        catch(ArithmeticException e) {
            System.out.println ("A number Can't divided by 0");
        }

	}

}
