package AssistedPractice;

public class SleepandWait {

	private static Object obj = new Object();	

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Thread Going to sleep...");
		Thread.sleep(1000);
		System.out.println("Thread woke up ");
		
		synchronized(obj)
		{
			System.out.println("Thread will wait...");
			//object.wait();
			obj.wait(100);
		}
		
		System.out.println("Thread woken up after notify() or timeout.");


		
	}
}
