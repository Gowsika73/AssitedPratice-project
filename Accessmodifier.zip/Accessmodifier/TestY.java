package Modifier2;
import Modifier1.TestN;
public class TestY extends TestN {

	public static void main(String[] args) {
		new TestN().methodpublic();
		new TestY().methodprotected();
		new TestY().methodpublic();

	}

}
