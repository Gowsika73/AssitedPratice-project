package Modifier1;

public class TestM {
       private int a=5;
	   long k=1000;
	   protected float f=10.5f;
       public void methodpublic(){
    	   System.out.println(" Public method");
    	   methodPrivate();
       }
       protected void methodprotected(){
    	   System.out.println(" Protected method");
    	   methodPrivate();
       }
        void method_default(){
    	   System.out.println(" Default method");
    	   methodPrivate();
       }
       private void methodPrivate(){
    	   System.out.println("TestM");
    	   System.out.println("value of int:"+a);
    	   System.out.println("value of long:"+k);
    	   System.out.println("value of float:"+f);
       }
       
	}


