package Modifier1;

public class TestP {
	public void main(String args[]){
		
		  new TestM().methodprotected();
		  new TestM().methodpublic();
		  new TestM().method_default();
		  new TestN().methodprotected();
		  new TestN().methodpublic();
		  System.out.println("Value of int"+new TestM().k);
	}
	
		
		public void methodPublic() {
			System.out.println("This is methodPublic classP");
		}

		protected void methodprotected() {
			System.out.println("This is methodProtected classP");
			
		}

		void methodDefault() {
			System.out.println("This is methodDefault classP");
		}
}
			  
			 
