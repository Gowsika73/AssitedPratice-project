package Modifier1;

public class TestN {
	protected long j=2222;
	public int b=5;
    double d=6.06;
    public void methodpublic(){
 	   System.out.println(" Public method:"+b);
 	   methodPrivate();
    }
    protected void methodprotected(){
 	   System.out.println(" Protected method:"+j);
 	   methodPrivate();
    }
     void method_default(){
 	   System.out.println("Default method:"+d);
 	   methodPrivate();
    }
    private void methodPrivate(){
 	  System.out.println("Private method");
 	  System.out.println("value of long:"+j);
 	  System.out.println("value of int:"+b);
 	  System.out.println("value of double:"+d);
 	   
    }
    
	}






