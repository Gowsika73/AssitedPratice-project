package Modifier2;
public class TestX {
    private int c=32;
    long i=4000;
    protected float e=41.4f;
    public char ch='a';
    public void methodpublic(){
  	   System.out.println(" We are in Public method");
     }
     protected void methodprotected(){
  	   System.out.println(" We are in Protected method");
     }
      void method_default(){
  	   System.out.println("We are in Default method");
  	   System.out.println(c);
  	   System.out.println(i);
  	   System.out.println(e);
    	System.out.println(ch);
     }
}
