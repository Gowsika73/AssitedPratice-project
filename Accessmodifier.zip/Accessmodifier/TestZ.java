package Modifier2;
import Modifier1.TestM;
public class TestZ extends TestM {

	public static void main(String[] args) {
		new TestM().methodpublic();
		new TestZ().methodprotected();
		new TestZ().methodpublic();
		

	}

}
