package AssistedPractice;

public class ThrowThrowsFinally {

	 static void method() throws ArithmeticException  
	    {  
	        System.out.println("Inside the Thorws method");  
	        throw new ArithmeticException("throwing ArithmeticException");  
	    }  
	public static void main(String[] args) {
		 try  
	        {  
	            method();  
	        }  
	        catch(ArithmeticException ae)  
	        {  
	            System.out.println("caught in main() method");  
	        } 
		 finally {
			 System.out.println("Final Block");
		 }

}
}
