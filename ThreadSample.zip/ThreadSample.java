package AssistedPractice;

public class ThreadSample extends Thread {  
    public void run(){
   	 System.out.println("Thread class");

}
    public static void main(String[] args) {
		ThreadSample ts=new ThreadSample();
		ts.start();
	}
}