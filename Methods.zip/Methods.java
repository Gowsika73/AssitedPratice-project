package AssistedPractice;
public class Methods {
	public int area(int b,int h){
		int result=(int)(0.5*(b*h));
		return result;
	}
	public static void main(String args[]){
		Methods a=new Methods();
		int value=a.area(5,7);
		System.out.println("Area:"+value);
	}
}
