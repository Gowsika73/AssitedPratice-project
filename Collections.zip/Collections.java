package AssistedPractice;
import java.util.*;
public class Collections {
               public static void main(String[] args) {
				System.out.println("Creating ArrayList");
				ArrayList<String> bank=new ArrayList<String>();   
			      bank.add("Indian Bank");
			      bank.add("HDFC");    	   
			      System.out.println(bank); 
			      
			      System.out.println("----------------------");
			      System.out.println("Creating Vector");
			      Vector<Integer> vec = new Vector();
			      vec.addElement(15); 
			      vec.addElement(30); 
			      System.out.println(vec);
			      
			      System.out.println("----------------------");
			      System.out.println("Creating LinkedList");
			      LinkedList<String> names=new LinkedList<String>();  
			      names.add("Alex");  
			      names.add("John");  	      
			      Iterator<String> itr=names.iterator();  
			      while(itr.hasNext()){  
			       System.out.println(itr.next()); 
			       
			      	} 
			      }  
			}


	


