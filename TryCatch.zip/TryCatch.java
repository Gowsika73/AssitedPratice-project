package AssistedPractice;

public class TryCatch {

	public static void main(String[] args) {
		try {
			
			int a= 44/0;
			System.out.println(a);
		}
		catch(Exception e) {
			System.out.println("Error occured");
			
		}

	}

}
