package AssistedPractice;

public class ClassandObject {
		 int studentid;
		 String studentname;
		 String studentcollege;
		public ClassandObject(int studentid, String studentname, String studentcollege) {
			
			this.studentid = studentid;
			this.studentname = studentname;
			this.studentcollege = studentcollege;
			System.out.println("Roll Number: "+studentid+"\n"+"Student Name: "+studentname+"\n"+"College Name: "+studentcollege);
		}
		  public static void main(String[] args) {
			ClassandObject co=new ClassandObject(001,"FFFF","YZX");
			
			
		}
		}
