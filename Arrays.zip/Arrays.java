package AssistedPractice;

public class Arrays {

	public static void main(String[] args) {
		int a[]=new int[5];
		a[0]=11;
		a[1]=22;
		a[2]=33;
		a[3]=44;
		a[4]=55;
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
	}

}
